package com.example.bella_mall

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
